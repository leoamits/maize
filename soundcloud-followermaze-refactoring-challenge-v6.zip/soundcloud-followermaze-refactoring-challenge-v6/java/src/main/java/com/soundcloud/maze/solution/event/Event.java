package com.soundcloud.maze.solution.event;

import com.soundcloud.maze.solution.parser.PayloadParser;
import com.soundcloud.maze.solution.processor.PayloadProcessor;

public abstract class Event<P extends PayloadParser, PP extends PayloadProcessor> {

    public abstract P getParser();

    public abstract PP getProcessor();
}
