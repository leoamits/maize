package com.soundcloud.maze.solution.processor.impl;


import com.soundcloud.maze.solution.payload.impl.UnfollowPayload;
import com.soundcloud.maze.solution.processor.PayloadProcessor;
import com.soundcloud.maze.solution.util.UserFollowManager;


public class UnfollowProcessor implements PayloadProcessor<UnfollowPayload> {

    @Override
    public void process(UnfollowPayload payload) {
        UserFollowManager.unFollow(payload.getFollowee(),payload.getFollower());
    }
}
