package com.soundcloud.maze.solution;


import com.soundcloud.maze.solution.util.SocketConnectionPool;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Client implements Runnable {

    private int portNumber = 9099;
    private SocketConnectionPool connectionPool;

    public Client(SocketConnectionPool connectionPool, int portNumber) {
        this.connectionPool = connectionPool;
        this.portNumber = portNumber;
    }

    @Override
    public void run() {
        System.out.println("Listening for client requests on " + portNumber);
        try {
            ServerSocket serverSocket = connectionPool.createConnection(portNumber);
            Socket clientSocket = serverSocket.accept();
            while (clientSocket != null) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                String userId = reader.readLine();
                if (userId != null) {
                    connectionPool.updateConnection(Long.parseLong(userId), clientSocket);
                    System.out.println("User connected: " + userId + " (" + connectionPool.size() + " total)");
                }
                clientSocket = serverSocket.accept();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
