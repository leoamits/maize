package com.soundcloud.maze.solution.event.impl;

import com.soundcloud.maze.solution.event.Event;
import com.soundcloud.maze.solution.parser.impl.BroadcastPayloadParser;
import com.soundcloud.maze.solution.processor.impl.BroadcastProcessor;


public class BroadcastEvent extends Event<BroadcastPayloadParser, BroadcastProcessor> {

    private BroadcastPayloadParser parser;
    private BroadcastProcessor processor;


    public BroadcastEvent() {
        this.parser = new BroadcastPayloadParser();
        this.processor = new BroadcastProcessor();
    }

    @Override
    public BroadcastPayloadParser getParser() {
        return this.parser;
    }

    @Override
    public BroadcastProcessor getProcessor() {
        return this.processor;
    }
}
