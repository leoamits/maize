package com.soundcloud.maze.solution.event;

import java.util.HashMap;
import java.util.Map;

/**
 * Manages the various types of supported events
 */
public class EventManager {

    private static Map<String, Event> register = new HashMap<String, Event>();

    private EventManager() {
    }

    public static void registerEvent(String eventType, Event event) {
        register.put(eventType, event);
    }

    public static Event getEvent(String str) {
        return register.get(str);
    }

}
