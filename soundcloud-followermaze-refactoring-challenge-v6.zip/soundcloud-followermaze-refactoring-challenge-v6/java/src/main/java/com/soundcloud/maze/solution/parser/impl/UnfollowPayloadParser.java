package com.soundcloud.maze.solution.parser.impl;

import com.soundcloud.maze.solution.parser.PayloadParser;
import com.soundcloud.maze.solution.payload.impl.UnfollowPayload;

/**
 *
 */
public class UnfollowPayloadParser implements PayloadParser<UnfollowPayload> {

    public UnfollowPayload parse(String payload) {
        String payloadParts[] = payload.split("\\|");
        long sequenceNumber = Long.parseLong(payloadParts[0]);
        long follower = Long.parseLong(payloadParts[2]);
        long followee = Long.parseLong(payloadParts[3]);
        return new UnfollowPayload(sequenceNumber, follower, followee, payload);
    }
}