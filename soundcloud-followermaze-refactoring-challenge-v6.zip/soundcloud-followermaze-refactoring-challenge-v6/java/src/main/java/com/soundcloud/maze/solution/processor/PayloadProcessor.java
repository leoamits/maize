package com.soundcloud.maze.solution.processor;

import com.soundcloud.maze.solution.util.DLQ;
import com.soundcloud.maze.solution.util.FailedMessages;
import com.soundcloud.maze.solution.payload.Payload;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;

/**
 *
 * Payload processing logic should be handled by the payload processor
 *
 * @param <P>
 */
public interface PayloadProcessor<P extends Payload> {

    default void addFailedMessage(FailedMessages message) {
        DLQ.getInstance().addMessage(message);
    }

    public void process(P payload);
     default void sendMessage(Socket socket, String message) {
        try {
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            writer.write(message + "\n");
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
