package com.soundcloud.maze.solution.payload.impl;

import com.soundcloud.maze.solution.payload.AbstractPayload;

public class MessagePayload extends AbstractPayload {

    long sender;
    long recipient;

    public MessagePayload(long sequenceNumber, long sender, long recipient, String rawPayload) {
        super(sequenceNumber, rawPayload);
        this.sender = sender;
        this.recipient = recipient;
    }

    public long getSender() {
        return sender;
    }

    public long getRecipient() {
        return recipient;
    }


    @Override
    public String toString() {
        return getRawPayload();
    }
}
