package com.soundcloud.maze.solution.event.impl;

import com.soundcloud.maze.solution.event.Event;
import com.soundcloud.maze.solution.parser.impl.UnfollowPayloadParser;
import com.soundcloud.maze.solution.processor.impl.UnfollowProcessor;

public class UnfollowEvent extends Event<UnfollowPayloadParser, UnfollowProcessor> {

    private UnfollowPayloadParser parser;
    private UnfollowProcessor processor;

    public UnfollowEvent() {
        this.parser = new UnfollowPayloadParser();
        this.processor = new UnfollowProcessor();
    }

    @Override
    public UnfollowPayloadParser getParser() {
        return this.parser;
    }

    @Override
    public UnfollowProcessor getProcessor() {
        return this.processor;
    }
}
