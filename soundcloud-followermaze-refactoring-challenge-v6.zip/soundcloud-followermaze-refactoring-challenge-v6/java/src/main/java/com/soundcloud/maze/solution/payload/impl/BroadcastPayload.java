package com.soundcloud.maze.solution.payload.impl;

import com.soundcloud.maze.solution.payload.AbstractPayload;

public class BroadcastPayload extends AbstractPayload {

    public BroadcastPayload(long sequenceNumber, String rawPayload) {
        super(sequenceNumber, rawPayload);
    }

    @Override
    public String toString() {
        return getRawPayload();
    }
}
