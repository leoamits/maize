package com.soundcloud.maze.solution.payload;

public abstract class AbstractPayload implements Payload {
    private long sequenceNumber;
    private String rawPayload;

    public AbstractPayload(long sequenceNumber, String rawPayload) {
        this.sequenceNumber = sequenceNumber;
        this.rawPayload = rawPayload;
    }

    public long getSequenceNumber() {
        return sequenceNumber;
    }

    public String getRawPayload() {
        return rawPayload;
    }

    public void setRawPayload(String rawPayload) {
        this.rawPayload = rawPayload;
    }
}
