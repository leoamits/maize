package com.soundcloud.maze.solution.processor.impl;

import com.soundcloud.maze.solution.util.FailedMessageReason;
import com.soundcloud.maze.solution.util.FailedMessages;
import com.soundcloud.maze.solution.payload.impl.BroadcastPayload;
import com.soundcloud.maze.solution.processor.PayloadProcessor;
import com.soundcloud.maze.solution.util.SocketConnectionPool;

import java.net.Socket;
import java.util.Map;

public class BroadcastProcessor implements PayloadProcessor<BroadcastPayload> {
    @Override
    public void process(BroadcastPayload payload) {
        for (Map.Entry<Long,Socket> connection : SocketConnectionPool.getInstance().getLiveConnections().entrySet()) {
            if (connection.getValue() == null) {
                addFailedMessage(new FailedMessages(payload.getRawPayload(), FailedMessageReason.CONNECTION_CLOSED,connection.getKey()));
                continue;
            }
            sendMessage(connection.getValue(), payload.toString());
        }
    }
}
