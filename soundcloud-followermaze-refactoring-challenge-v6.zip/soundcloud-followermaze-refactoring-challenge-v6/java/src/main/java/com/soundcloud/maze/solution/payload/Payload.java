package com.soundcloud.maze.solution.payload;


/**
 *  a marker interface for a payload.
 */
public interface Payload {

}
