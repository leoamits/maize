package com.soundcloud.maze.solution.parser.impl;

import com.soundcloud.maze.solution.parser.PayloadParser;
import com.soundcloud.maze.solution.payload.impl.StatusUpdatePayload;

public class StatusUpdatePayloadParser implements PayloadParser<StatusUpdatePayload> {

    public StatusUpdatePayload parse(String payload) {
        String payloadParts[] = payload.split("\\|");
        long sequenceNumber = Long.parseLong(payloadParts[0]);
        long statusUpdatedBy = Long.parseLong(payloadParts[2]);
        return new StatusUpdatePayload(sequenceNumber, statusUpdatedBy, payload);
    }
}