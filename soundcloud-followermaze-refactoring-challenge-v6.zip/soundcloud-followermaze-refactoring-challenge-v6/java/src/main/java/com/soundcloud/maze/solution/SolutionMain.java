package com.soundcloud.maze.solution;

import com.soundcloud.maze.solution.event.EventManager;
import com.soundcloud.maze.solution.event.impl.*;
import com.soundcloud.maze.solution.util.SocketConnectionPool;

/**
 *  This is the main class gets executed when gw run commands is the executed.
 */
public class SolutionMain {

    private final static int CLIENT_PORT = 9099;
    private final static int SERVER_PORT = 9090;

    public static void main(String args[]) {

        System.out.println("Solution's execution started");

        registerEvents();
        // instantiate the socket connection pool
        SocketConnectionPool socketConnectionPool=SocketConnectionPool.getInstance();

        // client thread & server thread
        Thread client=new Thread(new Client(socketConnectionPool,CLIENT_PORT));
        Thread server=new Thread(new Server(socketConnectionPool,SERVER_PORT));


        // starts threads
        server.start();
        client.start();
    }


    /**
     *  Register the various supported events;
     */
    private static void registerEvents() {
        System.out.println("Registering all the supported events");

        EventManager.registerEvent("F",new FollowEvent());
        EventManager.registerEvent("U",new UnfollowEvent());
        EventManager.registerEvent("B",new BroadcastEvent());
        EventManager.registerEvent("P",new MesssageEvent());
        EventManager.registerEvent("S",new StatusUpdateEvent());
    }


}
