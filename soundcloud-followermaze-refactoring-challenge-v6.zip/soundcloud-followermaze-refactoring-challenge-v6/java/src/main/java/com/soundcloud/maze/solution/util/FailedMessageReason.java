package com.soundcloud.maze.solution.util;

public enum FailedMessageReason {
    UNSUPPORTED_PAYLOAD,CONNECTION_CLOSED
}
