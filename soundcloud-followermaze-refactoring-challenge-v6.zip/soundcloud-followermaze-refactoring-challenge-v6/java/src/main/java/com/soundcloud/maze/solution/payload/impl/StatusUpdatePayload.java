package com.soundcloud.maze.solution.payload.impl;

import com.soundcloud.maze.solution.payload.AbstractPayload;


public class StatusUpdatePayload extends AbstractPayload {

    // Userid, who's status is updated
    private long statusUpdatedBy;

    public StatusUpdatePayload(long sequenceNumber, long statusUpdatedBy, String rawPayload) {
        super(sequenceNumber, rawPayload);
        this.statusUpdatedBy = statusUpdatedBy;
    }

    public long getStatusUpdatedBy() {
        return statusUpdatedBy;
    }


    @Override
    public String toString() {
        return getRawPayload();
    }

}
