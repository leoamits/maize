package com.soundcloud.maze.solution.parser;

import com.soundcloud.maze.solution.payload.Payload;

/**
 *  Takes string payload recieved from socket as an argument and convert that into jova payload object.
 *
 *  This contract helps in supporting future payloads as well.
 *
 * @param <P>
 */
public interface PayloadParser<P extends Payload> {
    P parse(String payload);
}
