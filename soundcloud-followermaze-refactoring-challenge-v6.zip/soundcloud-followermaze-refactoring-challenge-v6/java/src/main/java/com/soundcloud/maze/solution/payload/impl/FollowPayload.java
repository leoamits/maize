package com.soundcloud.maze.solution.payload.impl;

import com.soundcloud.maze.solution.payload.AbstractPayload;


public class FollowPayload extends AbstractPayload {

    private long follower;
    private long followee;

    public FollowPayload(long sequenceNumber, long follower, long followee, String rawPayload) {
        super(sequenceNumber, rawPayload);
        this.follower = follower;
        this.followee = followee;
    }

    public long getFollower() {
        return follower;
    }

    public long getFollowee() {
        return followee;
    }

    @Override
    public String toString() {
        return getRawPayload();
    }
}
