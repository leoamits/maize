package com.soundcloud.maze.solution.processor.impl;

import com.soundcloud.maze.solution.util.FailedMessageReason;
import com.soundcloud.maze.solution.util.FailedMessages;
import com.soundcloud.maze.solution.payload.impl.MessagePayload;
import com.soundcloud.maze.solution.processor.PayloadProcessor;
import com.soundcloud.maze.solution.util.SocketConnectionPool;
import java.net.Socket;

public class MessageProcessor implements PayloadProcessor<MessagePayload> {

    @Override
    public void process(MessagePayload payload) {
       Socket socket = SocketConnectionPool.getInstance().getConnection(payload.getRecipient());
       if(socket==null){
           addFailedMessage(new FailedMessages(payload.getRawPayload(), FailedMessageReason.CONNECTION_CLOSED,payload.getRecipient()));
           return;
       }
       sendMessage(socket, payload.toString());
    }

}
