package com.soundcloud.maze.solution.util;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collection;
import java.util.Map;

import java.util.concurrent.ConcurrentHashMap;


/**
 * Singleton class for managing the socket connections.
 */
public class SocketConnectionPool {

    private static SocketConnectionPool INSTANCE = null;
    private Map<Long, Socket> clientPool = new ConcurrentHashMap<>();

    private SocketConnectionPool() {
    }

    public ServerSocket createConnection(int portNumber) throws IOException {
        return new ServerSocket(portNumber);
    }

    public Socket getConnection(long userId) {
        return clientPool.get(userId);
    }

    public void updateConnection(long userId, Socket socket) {
        clientPool.put(userId, socket);
    }


    public static SocketConnectionPool getInstance() {
        if (INSTANCE == null) {
            synchronized (SocketConnectionPool.class) {
                INSTANCE = new SocketConnectionPool();
            }
        }
        return INSTANCE;
    }

    public Map<Long, Socket>  getLiveConnections() {
        return clientPool;
    }

    public int size() {
        return clientPool.size();
    }

}
