package com.soundcloud.maze.solution.event.impl;

import com.soundcloud.maze.solution.event.Event;
import com.soundcloud.maze.solution.parser.impl.FollowPayloadParser;
import com.soundcloud.maze.solution.processor.impl.FollowProcessor;

public class FollowEvent extends Event<FollowPayloadParser, FollowProcessor> {

    private FollowPayloadParser parser;
    private FollowProcessor processor;

    public FollowEvent(){
        this.parser=new FollowPayloadParser();
        this.processor=new FollowProcessor();
    }
    @Override
    public FollowPayloadParser getParser() {
        return parser;
    }

    @Override
    public FollowProcessor getProcessor() {
        return processor;
    }
}

