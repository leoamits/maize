package com.soundcloud.maze.solution.processor.impl;

import com.soundcloud.maze.solution.util.FailedMessageReason;
import com.soundcloud.maze.solution.util.FailedMessages;
import com.soundcloud.maze.solution.payload.impl.StatusUpdatePayload;
import com.soundcloud.maze.solution.processor.PayloadProcessor;
import com.soundcloud.maze.solution.util.SocketConnectionPool;
import com.soundcloud.maze.solution.util.UserFollowManager;

import java.net.Socket;

public class StatusUpdateProcessor implements PayloadProcessor<StatusUpdatePayload> {

    @Override
    public void process(StatusUpdatePayload payload) {
        for (long follower : UserFollowManager.getFollowers(payload.getStatusUpdatedBy())) {
            Socket socket = SocketConnectionPool.getInstance().getConnection(follower);
            if(socket==null){
                addFailedMessage(new FailedMessages(payload.getRawPayload(), FailedMessageReason.CONNECTION_CLOSED,follower));
                continue;
            }
            sendMessage(socket, payload.toString());
        }
    }
}
