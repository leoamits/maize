package com.soundcloud.maze.solution.event.impl;


import com.soundcloud.maze.solution.event.Event;
import com.soundcloud.maze.solution.parser.impl.MessagePayloadParser;
import com.soundcloud.maze.solution.processor.impl.MessageProcessor;

public class MesssageEvent extends Event<MessagePayloadParser, MessageProcessor> {

    private MessagePayloadParser parser;
    private MessageProcessor processor;

    public MesssageEvent() {
        this.parser = new MessagePayloadParser();
        this.processor = new MessageProcessor();
    }

    @Override
    public MessagePayloadParser getParser() {
        return this.parser;
    }

    @Override
    public MessageProcessor getProcessor() {
        return this.processor;
    }
}
