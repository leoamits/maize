package com.soundcloud.maze.solution.util;


public class FailedMessages {

    private String rawPayload;
    private FailedMessageReason reason;
    private long userId;

    public FailedMessages(String rawPayload, FailedMessageReason reason) {
        this.rawPayload = rawPayload;
        this.reason = reason;
        this.userId=-1;
    }


    public FailedMessages(String rawPayload, FailedMessageReason reason,Long userId) {
        this.rawPayload = rawPayload;
        this.reason = reason;
        this.userId=userId;
    }

    public String getRawPayload() {
        return rawPayload;
    }

    public void setRawPayload(String rawPayload) {
        this.rawPayload = rawPayload;
    }

    public FailedMessageReason getReason() {
        return reason;
    }

    public void setReason(FailedMessageReason reason) {
        this.reason = reason;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "FailedMessages{" +
                "rawPayload='" + rawPayload + '\'' +
                ", reason=" + reason +
                ", userId=" + userId +
                '}';
    }
}
