package com.soundcloud.maze.solution.processor.impl;

import com.soundcloud.maze.solution.util.FailedMessageReason;
import com.soundcloud.maze.solution.util.FailedMessages;
import com.soundcloud.maze.solution.payload.impl.FollowPayload;
import com.soundcloud.maze.solution.processor.PayloadProcessor;
import com.soundcloud.maze.solution.util.SocketConnectionPool;
import com.soundcloud.maze.solution.util.UserFollowManager;
import java.net.Socket;

public class FollowProcessor  implements PayloadProcessor<FollowPayload> {

    @Override
    public void process(FollowPayload payload) {
        UserFollowManager.follow(payload.getFollowee(),payload.getFollower());
        Socket socket = SocketConnectionPool.getInstance().getConnection(payload.getFollowee());
        if(socket==null){
            addFailedMessage(new FailedMessages(payload.getRawPayload(), FailedMessageReason.CONNECTION_CLOSED,payload.getFollowee()));
            return;
        }
        sendMessage(socket,payload.toString());
    }
}
