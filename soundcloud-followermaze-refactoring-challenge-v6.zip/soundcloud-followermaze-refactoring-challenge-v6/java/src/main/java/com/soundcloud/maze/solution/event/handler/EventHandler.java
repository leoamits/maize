package com.soundcloud.maze.solution.event.handler;


import com.soundcloud.maze.solution.util.DLQ;
import com.soundcloud.maze.solution.util.FailedMessages;



public interface EventHandler {

    void handle(String payload, String payLoadType);

    default void addFailedMessage(FailedMessages message) {

        DLQ.getInstance().addMessage(message);
    }

}
