package com.soundcloud.maze.solution.util;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;


/**
 * Util class for Managing the users
 */
public class UserFollowManager {

    static Map<Long, Set<Long>> users = new ConcurrentHashMap<>();

    public static void follow(Long toUser, Long fromUser) {
        Set<Long> followers = users.getOrDefault(toUser, ConcurrentHashMap.newKeySet());
        followers.add(fromUser);
        users.put(toUser, followers);
    }

    public static void unFollow(Long toUser, Long fromUser) {
        Set<Long> followers = users.getOrDefault(toUser, ConcurrentHashMap.newKeySet());
        followers.remove(fromUser);
        users.put(toUser, followers);
    }

    public static Set<Long> getFollowers(Long userId) {
        return users.getOrDefault(userId, ConcurrentHashMap.newKeySet());
    }

}
