package com.soundcloud.maze.solution.parser.impl;

import com.soundcloud.maze.solution.parser.PayloadParser;
import com.soundcloud.maze.solution.payload.impl.BroadcastPayload;

public class BroadcastPayloadParser implements PayloadParser<BroadcastPayload> {

    public BroadcastPayload parse(String payload) {
        String payloadParts[] = payload.split("\\|");
        long sequenceNumber = Long.parseLong(payloadParts[0]);
        return new BroadcastPayload(sequenceNumber, payload);
    }
}
