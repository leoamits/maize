package com.soundcloud.maze.solution.event.handler;

import com.soundcloud.maze.solution.util.FailedMessageReason;
import com.soundcloud.maze.solution.util.FailedMessages;

import com.soundcloud.maze.solution.event.Event;
import com.soundcloud.maze.solution.event.EventManager;
import com.soundcloud.maze.solution.payload.Payload;


/**
 *  This is the main event handler
 *  Algorithm :
 *  1) based on payload type identify the event
 *  2) invoke the parser, which returns the payload object
 *  3) Pass the payload to the processor for processing .
 */

public class ServerEventHandler implements EventHandler{

    @Override
    public void handle(String payloadString, String payLoadType){

        // identify the event
        Event event= EventManager.getEvent(payLoadType);

        if(event==null){
            addFailedMessage(new FailedMessages(payloadString, FailedMessageReason.UNSUPPORTED_PAYLOAD));
        }

        // parse the poyload
        Payload payload=event.getParser().parse(payloadString);

        // process the event
        event.getProcessor().process(payload);
    }
}
