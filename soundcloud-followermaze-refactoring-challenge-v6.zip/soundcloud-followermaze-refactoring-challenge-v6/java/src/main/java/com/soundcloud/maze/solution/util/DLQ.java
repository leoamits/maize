package com.soundcloud.maze.solution.util;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DLQ {

    private static DLQ INSTANCE=null;

    private DLQ() { }
    List<FailedMessages> messages= Collections.synchronizedList(new ArrayList<>());

    public void addMessage(FailedMessages failedMessages){
        messages.add(failedMessages);
        // uncomment following line in order to see how DLQ is filled
        //System.out.println(failedMessages.toString());
    }

    public int size(){
        return messages.size();
    }
    public static DLQ getInstance() {
        if (INSTANCE == null) {
            synchronized (DLQ.class) {
                INSTANCE = new DLQ();
            }
        }
        return INSTANCE;
    }

}
