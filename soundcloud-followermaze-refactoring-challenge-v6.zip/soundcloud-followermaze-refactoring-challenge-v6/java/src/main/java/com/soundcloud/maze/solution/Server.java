package com.soundcloud.maze.solution;




import com.soundcloud.maze.solution.event.handler.EventHandler;
import com.soundcloud.maze.solution.event.handler.ServerEventHandler;
import com.soundcloud.maze.solution.util.SocketConnectionPool;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *  Socket Server
 *
 */
public class Server implements  Runnable {

    private int portNumber = 9090;
    private SocketConnectionPool connectionPool;
    private EventHandler eventHandler;
    private static long lastSeqNo = 0L;
    Map<Long, String> seqNoToMessage = new HashMap<>();

    public Server(SocketConnectionPool connectionPool, int portNumber){
        this.connectionPool=connectionPool;
        this.eventHandler=new ServerEventHandler();
        this.portNumber=portNumber;
    }

    @Override
    public void run() {
        System.out.println("Listening for events on " + portNumber);
        try {
            Socket serverSocket =connectionPool.createConnection(portNumber).accept();
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));
                reader.lines().forEach(payload -> {
                    String payloadParts[]= payload.split("\\|");
                    seqNoToMessage.put(Long.parseLong(payloadParts[0]), payload);
                    while (seqNoToMessage.containsKey(lastSeqNo + 1)) {
                        String nextMessage = seqNoToMessage.get(lastSeqNo + 1);
                        seqNoToMessage.remove(lastSeqNo+1);
                        String nextMessageParts[]= nextMessage.split("\\|");
                        long seqNo = Long.parseLong(nextMessageParts[0]);
                        System.out.println("Message received: " + nextMessage);
                        eventHandler.handle(nextMessage,nextMessageParts[1]);
                        lastSeqNo = seqNo;
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
}
