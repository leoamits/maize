package com.soundcloud.maze.solution.parser.impl;

import com.soundcloud.maze.solution.parser.PayloadParser;
import com.soundcloud.maze.solution.payload.impl.MessagePayload;

public class MessagePayloadParser implements PayloadParser<MessagePayload> {

    public MessagePayload parse(String payload) {
        String payloadParts[] = payload.split("\\|");
        long sequenceNumber = Long.parseLong(payloadParts[0]);
        long sender = Long.parseLong(payloadParts[2]);
        long recipient = Long.parseLong(payloadParts[3]);
        return new MessagePayload(sequenceNumber, sender, recipient, payload);
    }
}
