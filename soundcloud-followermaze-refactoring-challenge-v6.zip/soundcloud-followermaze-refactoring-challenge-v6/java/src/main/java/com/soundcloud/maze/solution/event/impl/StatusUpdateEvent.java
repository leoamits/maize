package com.soundcloud.maze.solution.event.impl;

import com.soundcloud.maze.solution.event.Event;
import com.soundcloud.maze.solution.parser.impl.StatusUpdatePayloadParser;
import com.soundcloud.maze.solution.processor.impl.StatusUpdateProcessor;

public class StatusUpdateEvent extends Event<StatusUpdatePayloadParser, StatusUpdateProcessor> {

    private StatusUpdatePayloadParser parser;
    private StatusUpdateProcessor processor;

    public StatusUpdateEvent() {
        this.parser = new StatusUpdatePayloadParser();
        this.processor = new StatusUpdateProcessor();
    }

    @Override
    public StatusUpdatePayloadParser getParser() {
        return this.parser;
    }

    @Override
    public StatusUpdateProcessor getProcessor() {
        return this.processor;
    }
}
