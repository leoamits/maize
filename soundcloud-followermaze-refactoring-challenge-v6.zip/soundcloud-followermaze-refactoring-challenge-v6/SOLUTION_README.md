Notes :

1) This solution is implemented java programming language.
2) There are no changes done in the set up, with the exception that build.gradle file has been updated with main class.
   a new class com.soundcloud.maze.solution.SolutionMain.java us added. So, we can follow the same commands to run this solution.
3) Changes in build.gradle  mainClassName = "com.soundcloud.maze.solution.SolutionMain"
 
